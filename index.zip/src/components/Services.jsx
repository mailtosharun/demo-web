import React from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import Tilt from 'react-parallax-tilt'
import styled from 'styled-components'
import {
    Monitor,
    Smartphone,
    Cloud,
    Database,
    ShoppingCart,
    Palette
} from 'lucide-react'

const ServicesSection = styled.section`
  padding: 100px 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="dots" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="10" cy="10" r="1" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23dots)" /></svg>');
  }
`

const Container = styled.div`
  width: 100%;
  margin: 0 auto;
  padding: 0 40px;
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media (max-width: 768px) {
    padding: 0 20px;
  }
`

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 4rem);
  font-weight: 700;
  margin-bottom: 1rem;
  color: white;
`

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: clamp(1.1rem, 2.5vw, 1.3rem);
  color: rgba(255, 255, 255, 0.9);
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`

const ServicesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
  margin-top: 3rem;
  width: 100%;
  max-width: 1400px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }
`

const ServiceCard = styled(motion.div)`
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 2.5rem;
  text-align: center;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    transition: left 0.5s ease;
  }

  &:hover::before {
    left: 100%;
  }

  &:hover {
    transform: translateY(-10px);
    border-color: rgba(255, 255, 255, 0.3);
    background: rgba(255, 255, 255, 0.15);
  }

  .icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 1.5rem;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    transition: all 0.3s ease;
  }

  &:hover .icon {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
  }

  h3 {
    font-size: 1.5rem;
    font-weight: 600;
    color: white;
    margin-bottom: 1rem;
  }

  p {
    color: rgba(255, 255, 255, 0.8);
    line-height: 1.6;
    font-size: 1rem;
    margin-bottom: 1.5rem;
  }

  .features {
    list-style: none;
    padding: 0;
    margin: 0;
    text-align: left;

    li {
      color: rgba(255, 255, 255, 0.9);
      margin-bottom: 0.5rem;
      padding-left: 1rem;
      position: relative;

      &::before {
        content: '✓';
        position: absolute;
        left: 0;
        color: #4ade80;
        font-weight: bold;
      }
    }
  }
`

const CTASection = styled(motion.div)`
  margin-top: 4rem;
  text-align: center;
`

const CTAButton = styled(motion.a)`
  display: inline-block;
  padding: 18px 40px;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  text-decoration: none;
  border-radius: 50px;
  font-weight: 600;
  font-size: 1.1rem;
  border: 2px solid rgba(255, 255, 255, 0.3);
  backdrop-filter: blur(10px);
  transition: all 0.3s ease;

  &:hover {
    background: rgba(255, 255, 255, 0.3);
    border-color: rgba(255, 255, 255, 0.5);
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
  }
`

const Services = () => {
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    })

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.2
            }
        }
    }

    const itemVariants = {
        hidden: { opacity: 0, y: 50 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.8 }
        }
    }

    const services = [
        {
            icon: <Monitor size={40} />,
            title: 'Web Development',
            description: 'Custom web applications built with modern technologies and best practices.',
            features: [
                'Responsive Design',
                'Progressive Web Apps',
                'E-commerce Solutions',
                'CMS Development'
            ]
        },
        {
            icon: <Smartphone size={40} />,
            title: 'Mobile Apps',
            description: 'Native and cross-platform mobile applications for iOS and Android.',
            features: [
                'React Native Apps',
                'Native iOS & Android',
                'Cross-platform Solutions',
                'App Store Optimization'
            ]
        },
        {
            icon: <Cloud size={40} />,
            title: 'Cloud Solutions',
            description: 'Scalable cloud infrastructure and deployment solutions.',
            features: [
                'AWS & Azure Deployment',
                'Serverless Architecture',
                'DevOps & CI/CD',
                'Cloud Migration'
            ]
        },
        {
            icon: <Database size={40} />,
            title: 'Backend Development',
            description: 'Robust and scalable backend systems and APIs.',
            features: [
                'RESTful APIs',
                'GraphQL Integration',
                'Database Design',
                'Microservices'
            ]
        },
        {
            icon: <ShoppingCart size={40} />,
            title: 'E-commerce',
            description: 'Complete e-commerce solutions with payment integration.',
            features: [
                'Online Stores',
                'Payment Gateways',
                'Inventory Management',
                'Analytics Dashboard'
            ]
        },
        {
            icon: <Palette size={40} />,
            title: 'UI/UX Design',
            description: 'Beautiful and intuitive user interfaces and experiences.',
            features: [
                'User Research',
                'Wireframing',
                'Prototyping',
                'Design Systems'
            ]
        }
    ]

    return (
        <ServicesSection id="services" ref={ref}>
            <Container>
                <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate={inView ? "visible" : "hidden"}
                >
                    <SectionTitle variants={itemVariants}>
                        Our Services
                    </SectionTitle>

                    <SectionSubtitle variants={itemVariants}>
                        We offer comprehensive software development services to bring your ideas to life
                    </SectionSubtitle>

                    <ServicesGrid>
                        {services.map((service, index) => (
                            <Tilt
                                key={index}
                                tiltMaxAngleX={5}
                                tiltMaxAngleY={5}
                                perspective={1000}
                                scale={1.02}
                                transitionSpeed={1500}
                            >
                                <ServiceCard
                                    variants={itemVariants}
                                    whileHover={{ y: -10 }}
                                >
                                    <div className="icon">
                                        {service.icon}
                                    </div>
                                    <h3>{service.title}</h3>
                                    <p>{service.description}</p>
                                    <ul className="features">
                                        {service.features.map((feature, featureIndex) => (
                                            <li key={featureIndex}>{feature}</li>
                                        ))}
                                    </ul>
                                </ServiceCard>
                            </Tilt>
                        ))}
                    </ServicesGrid>

                    <CTASection variants={itemVariants}>
                        <CTAButton
                            href="#contact"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={(e) => {
                                e.preventDefault()
                                document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })
                            }}
                        >
                            Start Your Project
                        </CTAButton>
                    </CTASection>
                </motion.div>
            </Container>
        </ServicesSection>
    )
}

export default Services
