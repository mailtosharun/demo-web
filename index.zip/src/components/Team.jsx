import React from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import Tilt from 'react-parallax-tilt'
import styled from 'styled-components'
import { Linkedin, Twitter, Github } from 'lucide-react'

const TeamSection = styled.section`
  padding: 100px 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="hexagon" width="30" height="30" patternUnits="userSpaceOnUse"><polygon points="15,2 26,8 26,22 15,28 4,22 4,8" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23hexagon)" /></svg>');
  }
`

const Container = styled.div`
  width: 100%;
  margin: 0 auto;
  padding: 0 40px;
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media (max-width: 768px) {
    padding: 0 20px;
  }
`

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 4rem);
  font-weight: 700;
  margin-bottom: 1rem;
  color: white;
`

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: clamp(1.1rem, 2.5vw, 1.3rem);
  color: rgba(255, 255, 255, 0.9);
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`

const TeamGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
  margin-top: 3rem;
  width: 100%;
  max-width: 1200px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }
`

const TeamCard = styled(motion.div)`
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 2rem;
  text-align: center;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    transition: left 0.5s ease;
  }

  &:hover::before {
    left: 100%;
  }

  &:hover {
    transform: translateY(-10px);
    border-color: rgba(255, 255, 255, 0.3);
    background: rgba(255, 255, 255, 0.15);
  }
`

const TeamMemberAvatar = styled.div`
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, ${props => props.gradient || 'rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.1) 100%'});
  margin: 0 auto 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2.5rem;
  color: white;
  font-weight: 700;
  border: 3px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="dots" width="10" height="10" patternUnits="userSpaceOnUse"><circle cx="5" cy="5" r="1" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23dots)" /></svg>');
  }

  .initials {
    position: relative;
    z-index: 2;
  }
`

const TeamMemberName = styled.h3`
  font-size: 1.5rem;
  font-weight: 600;
  color: white;
  margin-bottom: 0.5rem;
`

const TeamMemberRole = styled.p`
  color: rgba(255, 255, 255, 0.8);
  font-size: 1rem;
  margin-bottom: 1rem;
  font-weight: 500;
`

const TeamMemberBio = styled.p`
  color: rgba(255, 255, 255, 0.7);
  line-height: 1.6;
  font-size: 0.9rem;
  margin-bottom: 1.5rem;
`

const SocialLinks = styled.div`
  display: flex;
  justify-content: center;
  gap: 1rem;
`

const SocialLink = styled(motion.a)`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  text-decoration: none;
  transition: all 0.3s ease;

  &:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
  }
`

const Team = () => {
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    })

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.2
            }
        }
    }

    const itemVariants = {
        hidden: { opacity: 0, y: 50 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.8 }
        }
    }

    const teamMembers = [
        {
            name: 'Alex Johnson',
            role: 'CEO & Lead Developer',
            bio: 'Full-stack developer with 8+ years of experience in building scalable web applications.',
            initials: 'AJ',
            gradient: 'rgba(74, 222, 128, 0.3) 0%, rgba(34, 197, 94, 0.2) 100%',
            social: {
                linkedin: '#',
                twitter: '#',
                github: '#'
            }
        },
        {
            name: 'Sarah Chen',
            role: 'UI/UX Designer',
            bio: 'Creative designer passionate about creating beautiful and intuitive user experiences.',
            initials: 'SC',
            gradient: 'rgba(251, 146, 60, 0.3) 0%, rgba(249, 115, 22, 0.2) 100%',
            social: {
                linkedin: '#',
                twitter: '#'
            }
        },
        {
            name: 'Mike Rodriguez',
            role: 'Mobile Developer',
            bio: 'iOS and Android developer specializing in React Native and native app development.',
            initials: 'MR',
            gradient: 'rgba(59, 130, 246, 0.3) 0%, rgba(37, 99, 235, 0.2) 100%',
            social: {
                linkedin: '#',
                github: '#'
            }
        },
        {
            name: 'Emily Davis',
            role: 'DevOps Engineer',
            bio: 'Cloud infrastructure specialist with expertise in AWS, Docker, and Kubernetes.',
            initials: 'ED',
            gradient: 'rgba(168, 85, 247, 0.3) 0%, rgba(147, 51, 234, 0.2) 100%',
            social: {
                linkedin: '#',
                twitter: '#',
                github: '#'
            }
        }
    ]

    return (
        <TeamSection id="team" ref={ref}>
            <Container>
                <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate={inView ? "visible" : "hidden"}
                >
                    <SectionTitle variants={itemVariants}>
                        Meet Our Team
                    </SectionTitle>

                    <SectionSubtitle variants={itemVariants}>
                        Talented individuals working together to create amazing software solutions
                    </SectionSubtitle>

                    <TeamGrid>
                        {teamMembers.map((member, index) => (
                            <Tilt
                                key={index}
                                tiltMaxAngleX={5}
                                tiltMaxAngleY={5}
                                perspective={1000}
                                scale={1.02}
                                transitionSpeed={1500}
                            >
                                <TeamCard
                                    variants={itemVariants}
                                    whileHover={{ y: -10 }}
                                >
                                    <TeamMemberAvatar gradient={member.gradient}>
                                        <span className="initials">{member.initials}</span>
                                    </TeamMemberAvatar>

                                    <TeamMemberName>{member.name}</TeamMemberName>
                                    <TeamMemberRole>{member.role}</TeamMemberRole>
                                    <TeamMemberBio>{member.bio}</TeamMemberBio>

                                    <SocialLinks>
                                        {member.social.linkedin && (
                                            <SocialLink
                                                href={member.social.linkedin}
                                                whileHover={{ scale: 1.1 }}
                                                whileTap={{ scale: 0.95 }}
                                            >
                                                <Linkedin size={20} />
                                            </SocialLink>
                                        )}
                                        {member.social.twitter && (
                                            <SocialLink
                                                href={member.social.twitter}
                                                whileHover={{ scale: 1.1 }}
                                                whileTap={{ scale: 0.95 }}
                                            >
                                                <Twitter size={20} />
                                            </SocialLink>
                                        )}
                                        {member.social.github && (
                                            <SocialLink
                                                href={member.social.github}
                                                whileHover={{ scale: 1.1 }}
                                                whileTap={{ scale: 0.95 }}
                                            >
                                                <Github size={20} />
                                            </SocialLink>
                                        )}
                                    </SocialLinks>
                                </TeamCard>
                            </Tilt>
                        ))}
                    </TeamGrid>
                </motion.div>
            </Container>
        </TeamSection>
    )
}

export default Team
