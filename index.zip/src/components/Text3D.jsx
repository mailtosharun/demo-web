// Simple 3D Text Component without external font dependency
import React from 'react'
import { Float, Center } from '@react-three/drei'

const Text3DComponent = () => {
    return (
        <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
            <Center>
                <mesh>
                    <boxGeometry args={[2, 0.8, 0.2]} />
                    <meshStandardMaterial color="#764ba2" />
                </mesh>
                <mesh position={[0, 0, 0.15]}>
                    <boxGeometry args={[1.8, 0.6, 0.1]} />
                    <meshStandardMaterial color="#667eea" />
                </mesh>
            </Center>
        </Float>
    )
}

export default Text3DComponent
