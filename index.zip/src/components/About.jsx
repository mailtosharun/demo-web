import React from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import Tilt from 'react-parallax-tilt'
import styled from 'styled-components'
import { Code, Rocket, Users, Award } from 'lucide-react'

const AboutSection = styled.section`
  padding: 100px 0;
  background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
  position: relative;
  overflow: hidden;
`

const Container = styled.div`
  width: 100%;
  margin: 0 auto;
  padding: 0 40px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media (max-width: 768px) {
    padding: 0 20px;
  }
`

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 4rem);
  font-weight: 700;
  margin-bottom: 1rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: clamp(1.1rem, 2.5vw, 1.3rem);
  color: #666;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`

const AboutContent = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  margin-bottom: 5rem;
  width: 100%;
  max-width: 1400px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
`

const AboutText = styled.div`
  h3 {
    font-size: clamp(1.8rem, 3vw, 2.5rem);
    font-weight: 600;
    margin-bottom: 1.5rem;
    color: #333;
  }

  p {
    font-size: clamp(1rem, 2vw, 1.2rem);
    line-height: 1.8;
    color: #666;
    margin-bottom: 1.5rem;
  }
`

const AboutImage = styled(motion.div)`
  position: relative;
  height: 400px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 20px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)" /></svg>');
  }

  .content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
    
    h4 {
      font-size: 2rem;
      margin-bottom: 1rem;
    }
    
    p {
      font-size: 1.1rem;
      opacity: 0.9;
    }
  }
`

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-top: 3rem;
  width: 100%;
  max-width: 1200px;
`

const StatCard = styled(motion.div)`
  background: white;
  padding: 2rem;
  border-radius: 20px;
  text-align: center;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
  }

  .icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 1rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  }

  h4 {
    font-size: 2.5rem;
    font-weight: 700;
    color: #333;
    margin-bottom: 0.5rem;
  }

  p {
    color: #666;
    font-size: 1.1rem;
  }
`

const About = () => {
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    })

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.2
            }
        }
    }

    const itemVariants = {
        hidden: { opacity: 0, y: 50 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.8 }
        }
    }

    const stats = [
        {
            icon: <Code size={30} />,
            number: '50+',
            label: 'Projects Completed'
        },
        {
            icon: <Users size={30} />,
            number: '25+',
            label: 'Happy Clients'
        },
        {
            icon: <Rocket size={30} />,
            number: '5+',
            label: 'Years Experience'
        },
        {
            icon: <Award size={30} />,
            number: '15+',
            label: 'Awards Won'
        }
    ]

    return (
        <AboutSection id="about" ref={ref}>
            <Container>
                <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate={inView ? "visible" : "hidden"}
                >
                    <SectionTitle variants={itemVariants}>
                        About Jestrel Studio
                    </SectionTitle>

                    <SectionSubtitle variants={itemVariants}>
                        We are a passionate team of developers, designers, and innovators
                        dedicated to creating exceptional software solutions.
                    </SectionSubtitle>

                    <AboutContent>
                        <motion.div variants={itemVariants}>
                            <AboutText>
                                <h3>Our Mission</h3>
                                <p>
                                    At Jestrel Studio, we believe in the power of technology to transform
                                    businesses and improve lives. Our mission is to deliver innovative,
                                    scalable, and user-centric software solutions that drive success for our clients.
                                </p>
                                <p>
                                    We combine cutting-edge technologies with creative problem-solving to
                                    build applications that not only meet current needs but also anticipate
                                    future challenges. Every project is an opportunity to push boundaries
                                    and create something extraordinary.
                                </p>
                            </AboutText>
                        </motion.div>

                        <Tilt
                            tiltMaxAngleX={5}
                            tiltMaxAngleY={5}
                            perspective={1000}
                            scale={1.02}
                            transitionSpeed={1500}
                        >
                            <AboutImage variants={itemVariants}>
                                <div className="content">
                                    <h4>Innovation Driven</h4>
                                    <p>Crafting tomorrow's solutions today</p>
                                </div>
                            </AboutImage>
                        </Tilt>
                    </AboutContent>

                    <StatsGrid>
                        {stats.map((stat, index) => (
                            <Tilt
                                key={index}
                                tiltMaxAngleX={5}
                                tiltMaxAngleY={5}
                                perspective={1000}
                                scale={1.02}
                            >
                                <StatCard
                                    variants={itemVariants}
                                    whileHover={{ y: -5 }}
                                >
                                    <div className="icon">
                                        {stat.icon}
                                    </div>
                                    <h4>{stat.number}</h4>
                                    <p>{stat.label}</p>
                                </StatCard>
                            </Tilt>
                        ))}
                    </StatsGrid>
                </motion.div>
            </Container>
        </AboutSection>
    )
}

export default About
