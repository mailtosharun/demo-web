import React from 'react'
import { motion } from 'framer-motion'
import styled from 'styled-components'
import {
    ArrowUp,
    Mail,
    Phone,
    MapPin,
    Linkedin,
    Twitter,
    Github,
    Instagram
} from 'lucide-react'

const FooterSection = styled.footer`
  background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
  color: white;
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)" /></svg>');
  }
`

const Container = styled.div`
  width: 100%;
  margin: 0 auto;
  padding: 0 40px;
  position: relative;
  z-index: 2;

  @media (max-width: 768px) {
    padding: 0 20px;
  }
`

const FooterContent = styled.div`
  padding: 80px 0 40px;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 3rem;
  max-width: 1400px;
  margin: 0 auto;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 2rem;
    text-align: center;
  }
`

const FooterBrand = styled.div`
  h3 {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  p {
    color: rgba(255, 255, 255, 0.8);
    line-height: 1.6;
    margin-bottom: 2rem;
    font-size: 1rem;
  }
`

const SocialLinks = styled.div`
  display: flex;
  gap: 1rem;

  @media (max-width: 768px) {
    justify-content: center;
  }
`

const SocialLink = styled(motion.a)`
  width: 50px;
  height: 50px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.1);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  text-decoration: none;
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.2);

  &:hover {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-color: transparent;
    transform: translateY(-3px);
  }
`

const FooterColumn = styled.div`
  h4 {
    font-size: 1.3rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    color: white;
  }

  ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  li {
    margin-bottom: 0.75rem;
  }

  a {
    color: rgba(255, 255, 255, 0.8);
    text-decoration: none;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 0.5rem;

    &:hover {
      color: #667eea;
      transform: translateX(5px);
    }
  }
`

const FooterBottom = styled.div`
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding: 30px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
`

const Copyright = styled.p`
  color: rgba(255, 255, 255, 0.6);
  margin: 0;
  font-size: 0.9rem;
`

const BackToTop = styled(motion.button)`
  width: 50px;
  height: 50px;
  border-radius: 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
  }
`

const Footer = () => {
    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        })
    }

    const quickLinks = [
        { href: '#home', label: 'Home' },
        { href: '#about', label: 'About' },
        { href: '#services', label: 'Services' },
        { href: '#portfolio', label: 'Portfolio' },
        { href: '#team', label: 'Team' },
        { href: '#contact', label: 'Contact' }
    ]

    const services = [
        'Web Development',
        'Mobile Apps',
        'Cloud Solutions',
        'UI/UX Design',
        'E-commerce',
        'Consulting'
    ]

    const contactInfo = [
        {
            icon: <Mail size={16} />,
            text: 'hello@jestrelstudio.com',
            href: 'mailto:hello@jestrelstudio.com'
        },
        {
            icon: <Phone size={16} />,
            text: '+1 (555) 123-4567',
            href: 'tel:+15551234567'
        },
        {
            icon: <MapPin size={16} />,
            text: '123 Innovation Street, Tech City',
            href: '#'
        }
    ]

    const socialMedia = [
        {
            icon: <Linkedin size={20} />,
            href: '#',
            label: 'LinkedIn'
        },
        {
            icon: <Twitter size={20} />,
            href: '#',
            label: 'Twitter'
        },
        {
            icon: <Github size={20} />,
            href: '#',
            label: 'GitHub'
        },
        {
            icon: <Instagram size={20} />,
            href: '#',
            label: 'Instagram'
        }
    ]

    const handleNavClick = (e, href) => {
        e.preventDefault()
        const element = document.querySelector(href)
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' })
        }
    }

    return (
        <FooterSection>
            <Container>
                <FooterContent>
                    <FooterBrand>
                        <h3>Jestrel Studio</h3>
                        <p>
                            We are passionate about creating innovative software solutions that
                            transform businesses and improve lives. Let's build something amazing together.
                        </p>
                        <SocialLinks>
                            {socialMedia.map((social, index) => (
                                <SocialLink
                                    key={index}
                                    href={social.href}
                                    whileHover={{ y: -3 }}
                                    whileTap={{ scale: 0.95 }}
                                    title={social.label}
                                >
                                    {social.icon}
                                </SocialLink>
                            ))}
                        </SocialLinks>
                    </FooterBrand>

                    <FooterColumn>
                        <h4>Quick Links</h4>
                        <ul>
                            {quickLinks.map((link, index) => (
                                <li key={index}>
                                    <a
                                        href={link.href}
                                        onClick={(e) => handleNavClick(e, link.href)}
                                    >
                                        {link.label}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </FooterColumn>

                    <FooterColumn>
                        <h4>Services</h4>
                        <ul>
                            {services.map((service, index) => (
                                <li key={index}>
                                    <a href="#services">{service}</a>
                                </li>
                            ))}
                        </ul>
                    </FooterColumn>

                    <FooterColumn>
                        <h4>Contact Info</h4>
                        <ul>
                            {contactInfo.map((info, index) => (
                                <li key={index}>
                                    <a href={info.href}>
                                        {info.icon}
                                        {info.text}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </FooterColumn>
                </FooterContent>

                <FooterBottom>
                    <Copyright>
                        © 2025 Jestrel Studio. All rights reserved.
                    </Copyright>

                    <BackToTop
                        onClick={scrollToTop}
                        whileHover={{ y: -3 }}
                        whileTap={{ scale: 0.95 }}
                        title="Back to top"
                    >
                        <ArrowUp size={20} />
                    </BackToTop>
                </FooterBottom>
            </Container>
        </FooterSection>
    )
}

export default Footer
