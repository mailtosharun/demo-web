import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { useForm } from 'react-hook-form'
import Tilt from 'react-parallax-tilt'
import styled from 'styled-components'
import {
    Mail,
    Phone,
    MapPin,
    Send,
    CheckCircle,
    AlertCircle,
    Clock
} from 'lucide-react'

const ContactSection = styled.section`
  padding: 100px 0;
  background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
  position: relative;
`

const Container = styled.div`
  width: 100%;
  margin: 0 auto;
  padding: 0 40px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media (max-width: 768px) {
    padding: 0 20px;
  }
`

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 4rem);
  font-weight: 700;
  margin-bottom: 1rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: clamp(1.1rem, 2.5vw, 1.3rem);
  color: #666;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`

const ContactContent = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: start;
  width: 100%;
  max-width: 1400px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
`

const ContactInfo = styled.div`
  h3 {
    font-size: 2rem;
    font-weight: 600;
    color: #333;
    margin-bottom: 1rem;
  }

  p {
    font-size: 1.1rem;
    color: #666;
    line-height: 1.6;
    margin-bottom: 2rem;
  }
`

const ContactItem = styled(motion.div)`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
  padding: 1rem;
  background: white;
  border-radius: 15px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
  }

  .icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    flex-shrink: 0;
  }

  .content {
    h4 {
      font-size: 1.1rem;
      font-weight: 600;
      color: #333;
      margin-bottom: 0.25rem;
    }

    p {
      color: #666;
      margin: 0;
      font-size: 1rem;
    }
  }
`

const ContactFormContainer = styled(motion.div)`
  background: white;
  padding: 2.5rem;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
`

const ContactForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`

const FormRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`

const Label = styled.label`
  font-weight: 600;
  color: #333;
  font-size: 1rem;
`

const Input = styled.input`
  padding: 15px 20px;
  border: 2px solid #e2e8f0;
  border-radius: 12px;
  font-size: 1rem;
  transition: all 0.3s ease;
  background: #f8fafc;

  &:focus {
    outline: none;
    border-color: #667eea;
    background: white;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }

  &.error {
    border-color: #ef4444;
  }
`

const TextArea = styled.textarea`
  padding: 15px 20px;
  border: 2px solid #e2e8f0;
  border-radius: 12px;
  font-size: 1rem;
  resize: vertical;
  min-height: 120px;
  font-family: inherit;
  transition: all 0.3s ease;
  background: #f8fafc;

  &:focus {
    outline: none;
    border-color: #667eea;
    background: white;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }

  &.error {
    border-color: #ef4444;
  }
`

const ErrorMessage = styled.span`
  color: #ef4444;
  font-size: 0.9rem;
  font-weight: 500;
`

const SubmitButton = styled(motion.button)`
  padding: 18px 30px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 12px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  position: relative;
  overflow: hidden;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
  }

  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s ease;
  }

  &:hover::before {
    left: 100%;
  }
`

const StatusMessage = styled(motion.div)`
  padding: 1rem;
  border-radius: 12px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 500;
  margin-top: 1rem;

  &.success {
    background: rgba(34, 197, 94, 0.1);
    color: #16a34a;
    border: 1px solid rgba(34, 197, 94, 0.2);
  }

  &.error {
    background: rgba(239, 68, 68, 0.1);
    color: #dc2626;
    border: 1px solid rgba(239, 68, 68, 0.2);
  }
`

const Contact = () => {
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    })

    const [formStatus, setFormStatus] = useState(null)
    const [isSubmitting, setIsSubmitting] = useState(false)

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm()

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.2
            }
        }
    }

    const itemVariants = {
        hidden: { opacity: 0, y: 50 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.8 }
        }
    }

    const contactItems = [
        {
            icon: <Mail size={24} />,
            title: 'Email Us',
            content: 'hello@jestrelstudio.com'
        },
        {
            icon: <Phone size={24} />,
            title: 'Call Us',
            content: '+1 (555) 123-4567'
        },
        {
            icon: <MapPin size={24} />,
            title: 'Visit Us',
            content: '123 Innovation Street, Tech City, TC 12345'
        },
        {
            icon: <Clock size={24} />,
            title: 'Business Hours',
            content: 'Mon - Fri: 9:00 AM - 6:00 PM'
        }
    ]

    const onSubmit = async (data) => {
        setIsSubmitting(true)
        setFormStatus(null)

        try {
            // Simulate form submission
            await new Promise(resolve => setTimeout(resolve, 2000))

            console.log('Form submitted:', data)
            setFormStatus({ type: 'success', message: 'Thank you! Your message has been sent successfully.' })
            reset()
        } catch {
            setFormStatus({ type: 'error', message: 'Sorry, there was an error sending your message. Please try again.' })
        } finally {
            setIsSubmitting(false)
        }
    }

    return (
        <ContactSection id="contact" ref={ref}>
            <Container>
                <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate={inView ? "visible" : "hidden"}
                >
                    <SectionTitle variants={itemVariants}>
                        Get In Touch
                    </SectionTitle>

                    <SectionSubtitle variants={itemVariants}>
                        Ready to start your next project? Let's discuss how we can help bring your ideas to life.
                    </SectionSubtitle>

                    <ContactContent>
                        <motion.div variants={itemVariants}>
                            <ContactInfo>
                                <h3>Let's Start a Conversation</h3>
                                <p>
                                    We'd love to hear about your project and discuss how our team can help you achieve your goals.
                                    Reach out to us using any of the methods below.
                                </p>

                                {contactItems.map((item, index) => (
                                    <ContactItem
                                        key={index}
                                        variants={itemVariants}
                                        whileHover={{ x: 5 }}
                                    >
                                        <div className="icon">
                                            {item.icon}
                                        </div>
                                        <div className="content">
                                            <h4>{item.title}</h4>
                                            <p>{item.content}</p>
                                        </div>
                                    </ContactItem>
                                ))}
                            </ContactInfo>
                        </motion.div>

                        <Tilt
                            tiltMaxAngleX={2}
                            tiltMaxAngleY={2}
                            perspective={1000}
                            scale={1.01}
                            transitionSpeed={1500}
                        >
                            <ContactFormContainer variants={itemVariants}>
                                <ContactForm onSubmit={handleSubmit(onSubmit)}>
                                    <FormRow>
                                        <FormGroup>
                                            <Label htmlFor="firstName">First Name</Label>
                                            <Input
                                                id="firstName"
                                                type="text"
                                                className={errors.firstName ? 'error' : ''}
                                                {...register('firstName', { required: 'First name is required' })}
                                            />
                                            {errors.firstName && (
                                                <ErrorMessage>{errors.firstName.message}</ErrorMessage>
                                            )}
                                        </FormGroup>

                                        <FormGroup>
                                            <Label htmlFor="lastName">Last Name</Label>
                                            <Input
                                                id="lastName"
                                                type="text"
                                                className={errors.lastName ? 'error' : ''}
                                                {...register('lastName', { required: 'Last name is required' })}
                                            />
                                            {errors.lastName && (
                                                <ErrorMessage>{errors.lastName.message}</ErrorMessage>
                                            )}
                                        </FormGroup>
                                    </FormRow>

                                    <FormGroup>
                                        <Label htmlFor="email">Email Address</Label>
                                        <Input
                                            id="email"
                                            type="email"
                                            className={errors.email ? 'error' : ''}
                                            {...register('email', {
                                                required: 'Email is required',
                                                pattern: {
                                                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                                    message: 'Invalid email address'
                                                }
                                            })}
                                        />
                                        {errors.email && (
                                            <ErrorMessage>{errors.email.message}</ErrorMessage>
                                        )}
                                    </FormGroup>

                                    <FormGroup>
                                        <Label htmlFor="subject">Subject</Label>
                                        <Input
                                            id="subject"
                                            type="text"
                                            className={errors.subject ? 'error' : ''}
                                            {...register('subject', { required: 'Subject is required' })}
                                        />
                                        {errors.subject && (
                                            <ErrorMessage>{errors.subject.message}</ErrorMessage>
                                        )}
                                    </FormGroup>

                                    <FormGroup>
                                        <Label htmlFor="message">Message</Label>
                                        <TextArea
                                            id="message"
                                            className={errors.message ? 'error' : ''}
                                            {...register('message', { required: 'Message is required' })}
                                        />
                                        {errors.message && (
                                            <ErrorMessage>{errors.message.message}</ErrorMessage>
                                        )}
                                    </FormGroup>

                                    <SubmitButton
                                        type="submit"
                                        disabled={isSubmitting}
                                        whileHover={{ scale: 1.02 }}
                                        whileTap={{ scale: 0.98 }}
                                    >
                                        {isSubmitting ? (
                                            <>
                                                <motion.div
                                                    animate={{ rotate: 360 }}
                                                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                                                >
                                                    <Clock size={20} />
                                                </motion.div>
                                                Sending...
                                            </>
                                        ) : (
                                            <>
                                                <Send size={20} />
                                                Send Message
                                            </>
                                        )}
                                    </SubmitButton>

                                    {formStatus && (
                                        <StatusMessage
                                            className={formStatus.type}
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                        >
                                            {formStatus.type === 'success' ? (
                                                <CheckCircle size={20} />
                                            ) : (
                                                <AlertCircle size={20} />
                                            )}
                                            {formStatus.message}
                                        </StatusMessage>
                                    )}
                                </ContactForm>
                            </ContactFormContainer>
                        </Tilt>
                    </ContactContent>
                </motion.div>
            </Container>
        </ContactSection>
    )
}

export default Contact
