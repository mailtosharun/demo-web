import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import Tilt from 'react-parallax-tilt'
import styled from 'styled-components'
import { ExternalLink, Github } from 'lucide-react'

const PortfolioSection = styled.section`
  padding: 100px 0;
  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
  position: relative;
`

const Container = styled.div`
  width: 100%;
  margin: 0 auto;
  padding: 0 40px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media (max-width: 768px) {
    padding: 0 20px;
  }
`

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 4rem);
  font-weight: 700;
  margin-bottom: 1rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: clamp(1.1rem, 2.5vw, 1.3rem);
  color: #666;
  margin-bottom: 3rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`

const FilterButtons = styled(motion.div)`
  display: flex;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 3rem;
  flex-wrap: wrap;
`

const FilterButton = styled(motion.button)`
  padding: 10px 20px;
  border: 2px solid #667eea;
  background: ${props => props.active ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'transparent'};
  color: ${props => props.active ? 'white' : '#667eea'};
  border-radius: 25px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    transform: translateY(-2px);
  }
`

const ProjectsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
  width: 100%;
  max-width: 1400px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`

const ProjectCard = styled(motion.div)`
  background: white;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  position: relative;

  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
  }
`

const ProjectImage = styled.div`
  height: 250px;
  background: linear-gradient(135deg, ${props => props.gradient || '#667eea 0%, #764ba2 100%'});
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)" /></svg>');
  }

  .placeholder {
    position: relative;
    z-index: 2;
    color: white;
    font-size: 1.5rem;
    font-weight: 600;
    text-align: center;
  }
`

const ProjectContent = styled.div`
  padding: 2rem;
`

const ProjectTitle = styled.h3`
  font-size: 1.5rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 0.5rem;
`

const ProjectCategory = styled.span`
  display: inline-block;
  padding: 4px 12px;
  background: rgba(102, 126, 234, 0.1);
  color: #667eea;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  margin-bottom: 1rem;
`

const ProjectDescription = styled.p`
  color: #666;
  line-height: 1.6;
  margin-bottom: 1.5rem;
`

const ProjectTech = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
`

const TechTag = styled.span`
  padding: 4px 8px;
  background: #f1f5f9;
  color: #475569;
  border-radius: 8px;
  font-size: 0.8rem;
  font-weight: 500;
`

const ProjectLinks = styled.div`
  display: flex;
  gap: 1rem;
`

const ProjectLink = styled(motion.a)`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 8px 16px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  text-decoration: none;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
  }

  &.secondary {
    background: transparent;
    color: #667eea;
    border: 1px solid #667eea;
  }

  &.secondary:hover {
    background: #667eea;
    color: white;
  }
`

const Portfolio = () => {
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    })

    const [activeFilter, setActiveFilter] = useState('All')

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1
            }
        }
    }

    const itemVariants = {
        hidden: { opacity: 0, y: 50 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.8 }
        }
    }

    const filters = ['All', 'Web Apps', 'Mobile Apps', 'E-commerce', 'Design']

    const projects = [
        {
            id: 1,
            title: 'E-Commerce Platform',
            category: 'E-commerce',
            description: 'A full-featured e-commerce platform with payment integration, inventory management, and admin dashboard.',
            tech: ['React', 'Node.js', 'MongoDB', 'Stripe'],
            gradient: '#667eea 0%, #764ba2 100%',
            links: {
                demo: '#',
                github: '#'
            }
        },
        {
            id: 2,
            title: 'Task Management App',
            category: 'Web Apps',
            description: 'A collaborative task management application with real-time updates and team collaboration features.',
            tech: ['Vue.js', 'Express', 'Socket.io', 'PostgreSQL'],
            gradient: '#f093fb 0%, #f5576c 100%',
            links: {
                demo: '#',
                github: '#'
            }
        },
        {
            id: 3,
            title: 'Fitness Tracker Mobile App',
            category: 'Mobile Apps',
            description: 'A comprehensive fitness tracking app with workout plans, progress tracking, and social features.',
            tech: ['React Native', 'Firebase', 'Redux', 'Chart.js'],
            gradient: '#4facfe 0%, #00f2fe 100%',
            links: {
                demo: '#',
                github: '#'
            }
        },
        {
            id: 4,
            title: 'Brand Identity Design',
            category: 'Design',
            description: 'Complete brand identity design including logo, color palette, typography, and brand guidelines.',
            tech: ['Figma', 'Adobe Illustrator', 'Photoshop'],
            gradient: '#fa709a 0%, #fee140 100%',
            links: {
                demo: '#'
            }
        },
        {
            id: 5,
            title: 'Restaurant Booking System',
            category: 'Web Apps',
            description: 'Online reservation system for restaurants with table management and customer notifications.',
            tech: ['React', 'Django', 'PostgreSQL', 'Twilio'],
            gradient: '#a8edea 0%, #fed6e3 100%',
            links: {
                demo: '#',
                github: '#'
            }
        },
        {
            id: 6,
            title: 'Crypto Trading Dashboard',
            category: 'Web Apps',
            description: 'Real-time cryptocurrency trading dashboard with advanced charts and portfolio management.',
            tech: ['Next.js', 'TypeScript', 'TradingView', 'WebSocket'],
            gradient: '#ff9a9e 0%, #fecfef 100%',
            links: {
                demo: '#',
                github: '#'
            }
        }
    ]

    const filteredProjects = activeFilter === 'All'
        ? projects
        : projects.filter(project => project.category === activeFilter)

    return (
        <PortfolioSection id="portfolio" ref={ref}>
            <Container>
                <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate={inView ? "visible" : "hidden"}
                >
                    <SectionTitle variants={itemVariants}>
                        Our Portfolio
                    </SectionTitle>

                    <SectionSubtitle variants={itemVariants}>
                        Explore our latest projects and see how we bring ideas to life
                    </SectionSubtitle>

                    <FilterButtons variants={itemVariants}>
                        {filters.map((filter) => (
                            <FilterButton
                                key={filter}
                                active={activeFilter === filter}
                                onClick={() => setActiveFilter(filter)}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                {filter}
                            </FilterButton>
                        ))}
                    </FilterButtons>

                    <ProjectsGrid>
                        <AnimatePresence>
                            {filteredProjects.map((project) => (
                                <Tilt
                                    key={project.id}
                                    tiltMaxAngleX={5}
                                    tiltMaxAngleY={5}
                                    perspective={1000}
                                    scale={1.02}
                                    transitionSpeed={1500}
                                >
                                    <ProjectCard
                                        variants={itemVariants}
                                        initial="hidden"
                                        animate="visible"
                                        exit="hidden"
                                        layout
                                    >
                                        <ProjectImage gradient={project.gradient}>
                                            <div className="placeholder">
                                                {project.title}
                                            </div>
                                        </ProjectImage>

                                        <ProjectContent>
                                            <ProjectCategory>{project.category}</ProjectCategory>
                                            <ProjectTitle>{project.title}</ProjectTitle>
                                            <ProjectDescription>{project.description}</ProjectDescription>

                                            <ProjectTech>
                                                {project.tech.map((tech, techIndex) => (
                                                    <TechTag key={techIndex}>{tech}</TechTag>
                                                ))}
                                            </ProjectTech>

                                            <ProjectLinks>
                                                <ProjectLink
                                                    href={project.links.demo}
                                                    whileHover={{ scale: 1.05 }}
                                                >
                                                    <ExternalLink size={16} />
                                                    Live Demo
                                                </ProjectLink>
                                                {project.links.github && (
                                                    <ProjectLink
                                                        href={project.links.github}
                                                        className="secondary"
                                                        whileHover={{ scale: 1.05 }}
                                                    >
                                                        <Github size={16} />
                                                        Code
                                                    </ProjectLink>
                                                )}
                                            </ProjectLinks>
                                        </ProjectContent>
                                    </ProjectCard>
                                </Tilt>
                            ))}
                        </AnimatePresence>
                    </ProjectsGrid>
                </motion.div>
            </Container>
        </PortfolioSection>
    )
}

export default Portfolio
