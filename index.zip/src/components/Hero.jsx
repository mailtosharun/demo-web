import React, { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Float } from '@react-three/drei'
import { motion } from 'framer-motion'
import Tilt from 'react-parallax-tilt'
import styled from 'styled-components'
import { ChevronDown } from 'lucide-react'
import Text3DComponent from './Text3D'

const HeroSection = styled.section`
  height: 100vh;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  overflow: hidden;
`

const HeroContent = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  width: 100%;
  max-width: 1400px;
  padding: 0 40px;
  z-index: 2;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    text-align: center;
    gap: 2rem;
    padding: 0 20px;
  }
`

const HeroText = styled.div`
  color: white;
`

const HeroTitle = styled(motion.h1)`
  font-size: clamp(3rem, 6vw, 5rem);
  font-weight: 700;
  margin-bottom: 1rem;
  line-height: 1.1;
`

const HeroSubtitle = styled(motion.p)`
  font-size: clamp(1.2rem, 2.5vw, 1.8rem);
  margin-bottom: 2rem;
  opacity: 0.9;
  line-height: 1.4;
`

const HeroDescription = styled(motion.p)`
  font-size: clamp(1rem, 2vw, 1.2rem);
  margin-bottom: 3rem;
  opacity: 0.8;
  line-height: 1.6;
`

const HeroButtons = styled(motion.div)`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    justify-content: center;
  }
`

const Button = styled(motion.a)`
  display: inline-block;
  padding: 15px 30px;
  border-radius: 50px;
  text-decoration: none;
  font-weight: 600;
  font-size: 1.1rem;
  transition: all 0.3s ease;
  cursor: pointer;
  border: 2px solid transparent;

  &.primary {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    border-color: rgba(255, 255, 255, 0.3);
    backdrop-filter: blur(10px);
  }

  &.secondary {
    background: transparent;
    color: white;
    border-color: white;
  }

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
  }

  &.primary:hover {
    background: rgba(255, 255, 255, 0.3);
  }

  &.secondary:hover {
    background: white;
    color: #667eea;
  }
`

const Canvas3D = styled.div`
  height: 500px;
  position: relative;

  @media (max-width: 768px) {
    height: 300px;
  }
`

const ParticleBackground = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
`

const ScrollIndicator = styled(motion.div)`
  position: absolute;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%);
  color: white;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  opacity: 0.8;

  @media (max-width: 768px) {
    bottom: 20px;
  }
`

// 3D Cube Component
const FloatingCube = ({ position }) => {
    return (
        <Float speed={1.5} rotationIntensity={1} floatIntensity={2}>
            <mesh position={position}>
                <boxGeometry args={[0.5, 0.5, 0.5]} />
                <meshStandardMaterial color="#764ba2" transparent opacity={0.8} />
            </mesh>
        </Float>
    )
}

// 3D Scene Component
const Scene3D = () => {
    return (
        <>
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} />
            <Text3DComponent />
            <FloatingCube position={[-2, 1, 0]} />
            <FloatingCube position={[2, -1, 0]} />
            <FloatingCube position={[0, 2, -1]} />
            <OrbitControls enableZoom={false} enablePan={false} />
        </>
    )
}

const Hero = () => {
    const handleScrollToNext = () => {
        const aboutSection = document.querySelector('#about')
        if (aboutSection) {
            aboutSection.scrollIntoView({ behavior: 'smooth' })
        }
    }

    return (
        <HeroSection id="home">
            <ParticleBackground>
                {/* Animated background particles */}
                {[...Array(20)].map((_, i) => (
                    <motion.div
                        key={i}
                        style={{
                            position: 'absolute',
                            width: '4px',
                            height: '4px',
                            background: 'rgba(255, 255, 255, 0.5)',
                            borderRadius: '50%',
                            left: `${Math.random() * 100}%`,
                            top: `${Math.random() * 100}%`,
                        }}
                        animate={{
                            y: [0, -30, 0],
                            opacity: [0.5, 1, 0.5],
                        }}
                        transition={{
                            duration: 3 + Math.random() * 2,
                            repeat: Infinity,
                            delay: Math.random() * 2,
                        }}
                    />
                ))}
            </ParticleBackground>

            <HeroContent>
                <HeroText>
                    <HeroTitle
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1, delay: 0.2 }}
                    >
                        Welcome to{' '}
                        <span className="gradient-text" style={{ color: 'white' }}>
                            Jestrel Studio
                        </span>
                    </HeroTitle>

                    <HeroSubtitle
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1, delay: 0.4 }}
                    >
                        Innovative Software Solutions
                    </HeroSubtitle>

                    <HeroDescription
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1, delay: 0.6 }}
                    >
                        We craft cutting-edge software solutions that transform ideas into reality.
                        From web applications to mobile apps, we deliver excellence in every line of code.
                    </HeroDescription>

                    <HeroButtons
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1, delay: 0.8 }}
                    >
                        <Button
                            href="#contact"
                            className="primary"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={(e) => {
                                e.preventDefault()
                                document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })
                            }}
                        >
                            Get Started
                        </Button>
                        <Button
                            href="#portfolio"
                            className="secondary"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={(e) => {
                                e.preventDefault()
                                document.querySelector('#portfolio')?.scrollIntoView({ behavior: 'smooth' })
                            }}
                        >
                            View Our Work
                        </Button>
                    </HeroButtons>
                </HeroText>

                <Tilt
                    tiltMaxAngleX={10}
                    tiltMaxAngleY={10}
                    perspective={1000}
                    scale={1.02}
                    transitionSpeed={2000}
                    gyroscope={true}
                >
                    <Canvas3D>
                        <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
                            <Suspense fallback={null}>
                                <Scene3D />
                            </Suspense>
                        </Canvas>
                    </Canvas3D>
                </Tilt>
            </HeroContent>

            <ScrollIndicator
                onClick={handleScrollToNext}
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
            >
                <span>Scroll Down</span>
                <ChevronDown size={24} />
            </ScrollIndicator>
        </HeroSection>
    )
}

export default Hero
